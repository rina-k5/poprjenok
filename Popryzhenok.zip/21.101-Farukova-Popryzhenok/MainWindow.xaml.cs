﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace _21._101_Farukova_Popryzhenok
{
    /// <summary>
    /// Логика взаимодействия для MainWindow.xaml
    /// </summary>
    /// 

    public class helper
    {
        public static bool flag = false; //Переменная, указывающая на факт изменения приоритета
        public static int priority = 0; //Новое значение приоритета

        public static Model.poprjenokEntities ent;
        public static Model.poprjenokEntities GetContext()
        {
            if (ent == null)
            {
                ent = new Model.poprjenokEntities();
            }
            return ent;
        }
    }

    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
            frame.Content = new AgentPage(frame);
        }

        //Обновление Frame
        private void frame_LoadCompleted(object sender, NavigationEventArgs e)
        {
            try
            {
                AgentPage agentPage = (AgentPage)e.Content;
                agentPage.Load();
            }
            catch { };
        }
    }

}
